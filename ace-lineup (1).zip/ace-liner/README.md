# ACE Liner

150 g line tracer with an 11-channel sensor bar and DIY silicone wheels. Pink wheels, chosen for taste, rarity at competitions, and to match the sensors' red lights.

## Specs

| | |
|---|---|
| Weight | 150 g |
| Controller | Arduino Nano |
| Motor driver | TB6612FNG |
| Motors | N20 |
| Sensor bar | 11-channel (V1 used 5 channels) |
| Start | JSumo start module |
| Power | Buck converter for logic |
| Wheels | DIY silicone, pink |

## V1

Fine on the beginner track. On the intermediate track it:

- loses the line at intersections
- is slow
- wiggles on straights

## V2 plan

The causes are in the math, so V2 starts from the math: [`../docs/ace_liner_v2_math.md`](../docs/ace_liner_v2_math.md).

| Problem | Cause | V2 fix |
|---|---|---|
| Wiggle | Under-damped steering loop (damping ratio below 1) | PD control with gains set from the damping formula |
| Loses line at intersections | Weighted average collapses to the middle when many sensors see the line | Detect the intersection with a sensor count `S_int`, ignore the error, and drive straight through |
| Slow | Speed set by trial and error | Curve speed limit `v_max = sqrt(mu*g*R)` from measured wheel friction |

## A bit of math

**Line position.** The bar gives `e = sum(x_i * s_i) / sum(s_i)`, a weighted average, so the position is finer than the sensor spacing. With 11 sensors the bar is wide, which helps on sharp turns.

**The wiggle.** Steering with proportional gain alone gives a damping ratio `zeta = L * sqrt(Kp) / (2 * sqrt(v))`. Below 1 it overshoots. Critical damping is at `Kp = 4v / L^2`. A derivative term raises `zeta` without lowering `Kp`.

**Traction.** At 150 g the push limit is only `1.5 N * mu`, so traction decides how fast the Liner can take a curve. See [`traction_and_speed.md`](../docs/traction_and_speed.md).

## Firmware

`firmware/ace_liner_v2/ace_liner_v2.ino` is a starter sketch for the PD loop, the intersection rule, and the lost-line rule. The pins and gains are placeholders. An 11-channel bar, the 6 TB6612FNG pins, and the start module use more pins than a Nano has free, so adapt `readBar()` to however the bar is wired (direct pins, shift register, or expansion board). Tune with the steps in section 6 of the math page.

## Specs still to measure

| | |
|---|---|
| Sensor spacing `d` | |
| Axle to sensor bar `L` | |
| Track width `T` | |
| Loop time | |
| Speed `v` | |
| Battery | |

## Results (fill in after testing)

| | V1 | V2 |
|---|---|---|
| Beginner track lap | | |
| Intermediate track lap | | |
| Intersections handled | | |
