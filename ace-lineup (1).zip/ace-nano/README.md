# ACE Nano

Compact sumobot. The point of the Nano is a small, cheap bot that juniors and peers can use to test their own sumobot code.

## V1 hardware

| Part | Detail |
|---|---|
| Board | Microbot Rover V1.3 (Arduino Nano + TB6612FNG motor driver) |
| Opponent sensors | 5 SHARP analog IR sensors on A1 to A5 |
| Line / dohyo edge sensors | 2 IR sensors on A6 and A7 |
| Strategy select | DIP switch on D2 and D4 |
| Start | JSumo start module |

## A bit of math

The four calibration constants below come from the SHARP model `r = a / d + b`: pick a detection distance and a closest distance, and the constants follow from them. See [`../docs/sharp_ir_distance.md`](../docs/sharp_ir_distance.md).

## Firmware notes

- Speed scales with how close the opponent is, using `speedFromReading()`.
- Four constants need tuning on the real robot:

| Constant | What it sets |
|---|---|
| `SHARP_DETECT_THRESHOLD` | Reading at which an opponent counts as detected |
| `SHARP_MAX_READING` | Reading at which the opponent is at its closest, for speed scaling |
| `LINE_EDGE_THRESHOLD` | Reading that means the sensor is on the white edge line |
| `LINE_SPIN_MS` | How long the bot spins away after hitting the edge |

## Firmware

`firmware/ace_nano/ace_nano.ino` runs the match logic: avoid the edge first, then charge the opponent (faster as the reading rises), otherwise open with the strategy from the DIP switch and search. The DIP switch on D2 and D4 picks the strategy (both off: spin search, D2 on: charge first, D4 on: arc right first). The motor, STBY, and start pins are placeholders, so take them from the Rover board's pin map.

## Power and noise

Capacitor plan, seven in total: one per SHARP sensor (5), one bulk capacitor across VM and GND at the motor driver, and one at the battery input. The SHARP sensors spike the supply when they fire, so the per-sensor capacitors matter.

## Still to add

- `cad/` and `photos/`
- A short guide for juniors on which constants to change first
