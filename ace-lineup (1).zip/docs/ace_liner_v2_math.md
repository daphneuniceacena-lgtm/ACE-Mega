# ACE Liner V2: the math

Goal: stop the wiggle, hold the line through intersections, and go faster on curves, using numbers instead of trial and error.

Symbols: `N` sensors, spacing `d` (mm), `v` speed (mm/s), `L` distance from the wheel axle to the sensor bar (mm), `y` sideways offset of the axle from the line, `theta` heading error (rad), `omega` turning rate (rad/s), `e` the position error measured by the sensor bar.

## 1. Line position from the sensor bar

Sensor `i` sits at `x_i = (i - (N-1)/2) * d`, so the middle of the bar is 0. With readings `s_i` (0/1, or analog after normalizing):

```
e = sum(x_i * s_i) / sum(s_i)
```

This is a weighted average. When two neighboring sensors see the line, `e` lands between them, so resolution is finer than `d`. Analog readings give finer positions still.

## 2. Why V1 wiggles

Small-angle motion of the car relative to the line:

```
y' = v * theta
theta' = omega
e = y + L * theta        (the bar looks ahead of the axle)
```

With proportional control `omega = -Kp * e`:

```
y'' + (Kp * L) y' + (Kp * v) y = 0
natural frequency  wn = sqrt(Kp * v)
damping ratio      zeta = L * sqrt(Kp) / (2 * sqrt(v))
```

`zeta < 1` means the car overshoots and wiggles. It gets worse when `Kp` or `v` goes up, or when the bar sits close to the axle (small `L`). Critical damping (`zeta = 1`) is at:

```
Kp_crit = 4 * v / L^2
```

Example: `v = 500 mm/s`, `L = 80 mm` gives `Kp_crit = 4*500/6400 = 0.31 rad/s per mm`. A 10 mm error commands about 3.1 rad/s of turn rate.

Turning rate to wheel speeds, with track width `T` (distance between wheels): `v_right - v_left = omega * T`. Split it as `v_left = v - omega*T/2` and `v_right = v + omega*T/2`.

## 3. Adding the derivative term

With `omega = -Kp*e - Kd*e'` and `e' = y' + L*theta' = v*theta + L*omega`:

```
(1 + Kd*L) y'' + (Kp*L + Kd*v) y' + (Kp*v) y = 0

zeta = (Kp*L + Kd*v) / (2 * sqrt(Kp * v * (1 + Kd*L)))
```

`Kd` raises damping through the `Kd*v` term. That lets you keep `Kp` high for tight corners and use `Kd` to kill the oscillation. In code, compute `e'` as `(e - e_prev) / dt`.

## 4. Intersections

Let `S = sum(s_i)`.

| Case | Meaning | Action |
|---|---|---|
| `S = 0` | Line lost | Keep turning toward the sign of the last `e` |
| `S >= S_int` | Many sensors on at once: intersection or wide mark. `e` is about 0 and carries no information | Ignore `e`, hold the heading, drive straight for `t = (L + w) / v` where `w` is the crossing width |
| otherwise | Normal | PD on `e` |

Choose `S_int` a few sensors above the most a plain line can light. A line of width `w_line` lights about `w_line / d` sensors. For example, `w_line = 20 mm` and `d = 8 mm` lights about 3, so `S_int = 6` on an 11-channel bar. Count how many sensors light on a straight line and on a real intersection, then set `S_int` between them.

This is the V1 failure: at an intersection the weighted average collapses to the middle, so the car steers on junk.

## 5. Speed on curves

The wheels slip when the needed sideways force beats friction:

```
v^2 / R > mu * g     ->     v_max = sqrt(mu * g * R)
```

Measure `mu` for your silicone wheels: put the car on a flat plate, tilt it until the car slides, and take `mu = tan(angle)`. Do this for each wheel set (pink, green, blue) and compare.

## 6. Tuning from measured data

Model errors (motor lag, sensor sampling delay, wheel slip) mean the formulas are a guide, so confirm them on the track.

1. Measure `v`, `L`, `T`, `d`, and the loop time `dt`.
2. Start at `Kp = Kp_crit / 2` with `Kd = 0`. Log `e` at 100 Hz or faster.
3. Put the car on a small step offset from the line and record the response. If the peak overshoot is `M` as a fraction of the step:

```
zeta = -ln(M) / sqrt(pi^2 + ln(M)^2)
```

4. For P-only control `zeta` scales with `sqrt(Kp)`, so `Kp_new = Kp_old * (zeta_target / zeta_measured)^2`, with `zeta_target` around 0.7.
5. Then add `Kd` from section 3 to push `Kp` higher while keeping `zeta` near 0.7.

The overshoot formula comes from a plain second-order system. With `Kd` added there is an extra zero, so treat the result as approximate and fine-tune on the track.

## Results to fill in (for the portfolio page)

| | V1 | V2 |
|---|---|---|
| Kp / Kd | | |
| Measured overshoot M | | |
| zeta | | |
| Lap time, beginner track | | |
| Lap time, intermediate track | | |
| Intersections handled / total | | |
