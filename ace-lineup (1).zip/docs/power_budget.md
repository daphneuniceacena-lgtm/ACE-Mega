# Power budget

Applies to the 11.1 V LiPo builds (Micro and Mega), and to any robot with a buck converter.

## 1. The battery

A 3S LiPo is 3 cells in series:

```
nominal 3 * 3.7 = 11.1 V      full 3 * 4.2 = 12.6 V      empty about 3 * 3.0 = 9.0 V
```

Don't run it below about 3.3 V per cell (9.9 V) under load.

Runtime for a battery of capacity `C` (Ah) and average current `I` (A), using about 80% of the capacity:

```
t = 0.8 * C / I
```

Sag: the battery has internal resistance `R_int`, so the terminal voltage drops when current flows:

```
V_terminal = V_open_circuit - I * R_int
```

This is the cause of the brown-outs when the motors start: a current spike pulls the voltage down, and anything on the same rail can reset. It is why the logic runs from a separate regulated rail and has bulk capacitors.

## 2. Buck converter (LM2596) versus a linear regulator

A linear regulator burns the whole voltage difference as heat:

```
P_linear = (Vin - Vout) * I          example: (11.1 - 5) * 1 A = 6.1 W of heat
```

A buck converter with efficiency `eta` loses only a fraction of the output power:

```
P_loss = P_out * (1/eta - 1)         example: 5 W out at eta = 0.8 -> 1.25 W of heat
```

Take `eta` from the converter's datasheet curve at your load, or measure `Vin * Iin` against `Vout * Iout`. Set the output voltage with the converter's trimmer and check it with a multimeter before connecting the logic.

## 3. Stall current and the fuse

When the robot is stalled in a pushing match, each motor draws its stall current:

```
I_stall = V / R_winding
```

Add the stall currents of all motors. That total has to fit three limits:

| Limit | Rule |
|---|---|
| Motor driver | Must stay under the driver's peak current rating (check the TB6612FNG or BTS7960 datasheet per channel) |
| Wiring | Must stay under what the wire and connectors carry without heating |
| Fuse (15 A automotive blade on the Mega) | Above the normal running current, so it doesn't trip during a match, and below what the wiring and driver can survive |

A blade fuse carries its rated current indefinitely and trips faster the more it is overloaded. Read its time-current curve instead of guessing. Check the JGA25 motors' stall current against the TB6612FNG per-channel rating before trusting the Micro's driver in a long push.

## Results (fill in)

| Robot | Battery capacity | Measured average current | Estimated runtime | Motor stall current (total) |
|---|---|---|---|---|
| Micro | | | | |
| Mega | | | | |
