# SHARP IR sensors: reading to distance

The SHARP analog sensors do not give distance in a straight line. The output falls off roughly as the inverse of distance, which is why a plain threshold on the raw reading is awkward to tune.

## 1. Model

```
r = a / d + b
```

`r` is the ADC reading, `d` the distance to the opponent, `a` and `b` constants for each sensor. It holds beyond the sensor's minimum distance. Closer than that the output drops again, so don't use readings from inside it.

Because `r` is a straight line in `1 / d`, you only need two measured points to find `a` and `b`:

```
a = (r1 - r2) / (1/d1 - 1/d2)
b = r1 - a / d1
```

Then:

```
d = a / (r - b)
```

Use more than two points and a least-squares line of `r` against `1/d` for a better fit. Calibrate each sensor on its own, since they differ. Work in raw ADC readings: the Nano's ADC and the RP2040's ADC have different ranges, so the constants are not shared between the Micro and the Mega.

## 2. Procedure

1. Put a flat opponent-sized target at 10, 15, 20, 30, 40, 60 cm from the sensor, in the robot's real lighting.
2. At each distance, average 50 readings.
3. Plot `r` against `1/d`. The points should lie close to a line. Drop any point from inside the minimum distance.
4. Fit the line to get `a` and `b`.

## 3. Choosing the constants in the code

For a chosen detection distance `d_detect` and closest distance `d_close`:

```
SHARP_DETECT_THRESHOLD = a / d_detect + b
SHARP_MAX_READING      = a / d_close  + b
```

Proportional speed scaling, so the robot pushes harder as the opponent gets closer:

```
speed = base + (max - base) * clamp((r - THRESH) / (MAX - THRESH), 0, 1)
```

## 4. Can the opponent slip between the beams?

The sensors' beams are narrow. With two neighboring beams at an angle `alpha` apart, the gap between them at distance `d` is about:

```
gap(d) = d * tan(alpha)
```

An opponent of width `w` can sit between the two beams without either seeing it when `gap(d) > w`, that is beyond:

```
d_blind = w / tan(alpha)
```

Use it to place the sensors: for a given opponent width, pick `alpha` so that `d_blind` is beyond the distance the opponent can reach in one reaction time. Mega has 3 front sensors for this reason. Record the angle you chose.

## Results (fill in)

| Robot | Sensor | a | b | Fit quality |
|---|---|---|---|---|
| Micro | front | | | |
| Mega | front left | | | |
