# Traction and speed

Why the wheel experiments matter, with numbers. Symbols: `m` mass (kg), `g` = 9.81 m/s^2, `mu` friction coefficient between wheel and dohyo, `D` wheel diameter (m), `r = D/2`, `n` wheel speed (RPM).

## 1. Wheel speed

```
v = pi * D * n / 60
```

Example: `D = 40 mm`, `n = 620 RPM` (the JGA25 no-load speed) gives `v = pi * 0.04 * 620 / 60 = 1.30 m/s`. That is the no-load top speed. Under load the motor turns slower, so measure `n` with the robot on the dohyo and use the measured value.

## 2. Traction limit

All driven wheels share the weight, so the most force the robot can push with before the wheels slip is:

```
F_max = mu * m * g
```

| Robot | Mass | F_max |
|---|---|---|
| Liner | 0.15 kg | 1.5 N * mu |
| Micro | 0.5 kg | 4.9 N * mu |
| Mega | 1.0 kg | 9.8 N * mu |

This is why the wheels matter as much as the motors: two robots of the same mass push with a force in the ratio of their `mu`. A wheel with `mu = 1.2` pushes 50% harder than one with `mu = 0.8`, on the same motors.

## 3. Do the motors or the wheels give up first?

Torque each driven wheel needs to reach the traction limit, with 2 driven wheels:

```
tau_wheel = mu * m * g * r / 2
```

Micro example, `mu = 1.0`, `D = 40 mm`: `tau = 1.0 * 0.5 * 9.81 * 0.02 / 2 = 0.049 N*m`, about 0.5 kg*cm per wheel.

Compare that to the motor's torque at the wheel (stall torque times gear efficiency, from the datasheet or measured). If the motor can deliver more than `tau_wheel`, the wheels slip first and extra motor power is wasted. Grip and weight then decide the match. If the motor delivers less, the motor limits you and a grippier wheel does nothing until the torque goes up.

## 4. Acceleration

Traction also caps acceleration:

```
a_max = mu * g          t_to_speed = v / (mu * g)
```

Micro example: reaching 1.30 m/s at `mu = 1` takes at least `1.30 / 9.81 = 0.13 s`. A robot that spins its wheels at the start is wasting that time.

## 5. Measuring `mu`

Measure it on the real dohyo surface, with each wheel set (pink, green, blue):

- **Tilt test:** put the robot on a plate covered with the dohyo material, tilt slowly until it starts to slide, and take `mu = tan(angle)`.
- **Pull test:** pull the robot with a spring scale at a steady rate. At the moment it starts to slide, `mu = F / (m * g)`.

Repeat 5 times per wheel set and record the mean and the spread. Dust on the surface changes `mu` a lot, so wipe it and test again.

## Results (fill in)

| Wheel set | Robot | mu (mean) | Spread |
|---|---|---|---|
| Blue, attempt 1 | Mega | | |
| Pink | Micro V1 | | |
| Neon green, attempt 3 | Micro V2 | | |
| Pink | Liner | | |
